clear all; close all; clc;

%SaliencyMap Path
SalMapPath = '../SalMap/';  %The saliency map results can be downloaded from our webpage: http://dpfan.net/d3netbenchmark/

%Evaluated Models

Models = {'TEST-MODEL'};
%Models = {'CBCS','ESMG','RFPR','CSHS','SACS','CODR','UMLF','DIM','CODW','MIL','IML','GONet','SPMIL','CSMG','CPD','EGNet','HCNco','IPCS','PCSD'};

%Datasets
DataPath = '../Dataset/';

Datasets = {'TEST-DATASET'}
%Datasets = {'MSRC','CoSal2015','iCoSeg','ImagePair','CoSOD3k'};

%Evaluated Score Results
ResDir = '../Result_overall/';

%Initial paramters setting
Thresholds = 1:-1/255:0;
datasetNum = length(Datasets);
modelNum = length(Models);

for d = 1:datasetNum
    
    tic;
    dataset = Datasets{d};
    fprintf('Processing %d/%d: %s Dataset\n',d,datasetNum,dataset);
    
    ResPath = [ResDir dataset '-mat/'];
    if ~exist(ResPath,'dir')
        mkdir(ResPath);
    end
    resTxt = [ResDir dataset '_result-overall.txt'];
    fileID = fopen(resTxt,'w');
    
    for m = 1:modelNum
        model = Models{m};
           
        
        ctgs=dir([ DataPath dataset '/GroundTruth']);
        ctgs={ctgs.name};
        ctgs=ctgs(:,3:end);
        ctgsNum=length(ctgs);      
        
        
        
        [threshold_Fmeasure_ctg, threshold_Emeasure_ctg] = deal(zeros(ctgsNum,length(Thresholds)));

        [threshold_Precion_ctg, threshold_Recall_ctg] = deal(zeros(ctgsNum,length(Thresholds)));

        [Smeasure_ctg, adpFmeasure_ctg, adpEmeasure_ctg, MAE_ctg] =deal(zeros(1,ctgsNum));
        
     
        for c =1:ctgsNum
            ctg=char(ctgs(c));
            
            
            gtPath = [DataPath dataset '/GroundTruth/' ctg '/'];
            
            
            salPath = [SalMapPath model '/' dataset '/' ctg '/'];

            imgFiles = dir([salPath '*.png']);
            imgNUM = length(imgFiles);

            [threshold_Fmeasure, threshold_Emeasure] = deal(zeros(imgNUM,length(Thresholds)));

            [threshold_Precion, threshold_Recall] = deal(zeros(imgNUM,length(Thresholds)));

            [Smeasure, adpFmeasure, adpEmeasure, MAE] =deal(zeros(1,imgNUM));

            for i = 1:imgNUM  %parfor i = 1:imgNUM  You may also need the parallel strategy. 

                fprintf('Evaluating(%s Dataset,%s Model, %s): %d/%d\n',dataset, model,ctg, i,imgNUM);
                name =  imgFiles(i).name;

                %load gt
                gt = imread([gtPath name]);

                if (ndims(gt)>2)
                    gt = rgb2gray(gt);
                end

                if ~islogical(gt)
                    gt = gt(:,:,1) > 128;
                end

                %load salency
                sal  = imread([salPath name]);

                %check size
                if size(sal, 1) ~= size(gt, 1) || size(sal, 2) ~= size(gt, 2)
                    sal = imresize(sal,size(gt));
                    imwrite(sal,[salPath name]);
                    fprintf('Error occurs in the path: %s!!!\n', [salPath name]); %check whether the size of the salmap is equal the gt map.
                end

                sal = im2double(sal(:,:,1));

                %normalize sal to [0, 1]
                sal = reshape(mapminmax(sal(:)',0,1),size(sal));
                Sscore = StructureMeasure(sal,logical(gt));
                Smeasure(i) = Sscore;

                % Using the 2 times of average of sal map as the adaptive threshold.
                threshold =  2* mean(sal(:)) ;
                [~,~,adpFmeasure(i)] = Fmeasure_calu(sal,double(gt),size(gt),threshold);


                Bi_sal = zeros(size(sal));
                Bi_sal(sal>threshold)=1;
                adpEmeasure(i) = Enhancedmeasure(Bi_sal,gt);

                [threshold_F, threshold_E]  = deal(zeros(1,length(Thresholds)));
                [threshold_Pr, threshold_Rec]  = deal(zeros(1,length(Thresholds)));

                for t = 1:length(Thresholds)
                    threshold = Thresholds(t);
                    [threshold_Pr(t), threshold_Rec(t), threshold_F(t)] = Fmeasure_calu(sal,double(gt),size(gt),threshold);

                    Bi_sal = zeros(size(sal));
                    Bi_sal(sal>threshold)=1;
                    threshold_E(t) = Enhancedmeasure(Bi_sal,gt);
                end

                threshold_Fmeasure(i,:) = threshold_F;
                threshold_Emeasure(i,:) = threshold_E;
                threshold_Precion(i,:) = threshold_Pr;
                threshold_Recall(i,:) = threshold_Rec;

                MAE(i) = mean2(abs(double(logical(gt)) - sal));

            end

            %Precision and Recall 
            column_Pr = mean(threshold_Precion,1);
            threshold_Precion_ctg(c,:)=column_Pr;
            column_Rec = mean(threshold_Recall,1);
            threshold_Recall_ctg(c,:)=column_Rec;
            

            %Mean, Max F-measure score
            column_F = mean(threshold_Fmeasure,1);
            threshold_Fmeasure_ctg(c,:)=column_F;
            
           
            %Mean, Max E-measure score
            column_E = mean(threshold_Emeasure,1);
            threshold_Emeasure_ctg(c,:)=column_E;

            %Adaptive threshold for F-measure and E-measure score
            adpFm = mean2(adpFmeasure);
            adpFmeasure_ctg(c)=adpFm;
            adpEm = mean2(adpEmeasure);
            adpEmeasure_ctg(c)=adpEm;
            
            %Smeasure score
            Smeasure = mean2(Smeasure);
            Smeasure_ctg(c)=Smeasure;

            %MAE score
            mae = mean2(MAE);
            MAE_ctg(c)=mae;
            
        end
        column_Pr_final = mean(threshold_Precion_ctg);
        column_Rec_final= mean(threshold_Recall_ctg);
        
        meanFm_final =  mean(mean(threshold_Fmeasure_ctg));
        maxFm_final=  max(mean(threshold_Fmeasure_ctg));
        meanEm_final = mean(mean(threshold_Emeasure_ctg));
        maxEm_final = max(mean(threshold_Emeasure_ctg));
        adpFm_final = mean2(adpFmeasure_ctg);
        adpEm_final = mean2(adpEmeasure_ctg);
        Smeasure_final = mean2(Smeasure_ctg);
        MAE_final = mean2(MAE_ctg);
        
        %Save the mat file so that you can reload the mat file and plot the PR Curve
        save([ResPath model],'Smeasure_final', 'MAE_final', 'column_Pr_final', 'column_Rec_final', 'adpFm_final', 'meanFm_final', 'maxFm_final', 'adpEm_final', 'meanEm_final', 'maxEm_final');
        
        fprintf(fileID, '(Dataset:%s; Model:%s) Smeasure:%.3f; MAE:%.3f; adpEm:%.3f; meanEm:%.3f; maxEm:%.3f; adpFm:%.3f; meanFm:%.3f; maxFm:%.3f.\n',dataset,model,Smeasure_final, MAE_final, adpEm_final, meanEm_final, maxEm_final, adpFm_final, meanFm_final, maxFm_final);   
        
        %fprintf(fileID, '(Dataset:%s; Model:%s) S:%.3f; F:%.3f; E:%.3f; M:%.3f.\n',dataset,model,Smeasure_final, maxFm_final,maxEm_final,MAE_final);   
    end
    toc;
    
end


